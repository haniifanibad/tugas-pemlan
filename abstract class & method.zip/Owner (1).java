public class Owner {
    private String name;
    //buat constructor
    public Owner(String name){
        this.name = name;
    }

    //buat method getter untuk mendapatkan nilai name

    public String getName(){
        return this.name;
    }
}